# Flutter_torch

A its a simple flashlight app created with flutter.

### Play store 
[playstore](https://play.google.com/store/apps/details?id=com.alikghosh.flutter_torch)

<a href="https://play.google.com/store/apps/details?id=com.alikghosh.flutter_torch"> <img src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png" width="150" height="80"> </a>

> Download and check this app out 

### Technologies Used
` <Flutter> `

<a href="https://flutter.dev/"> https://flutter.dev/ </a>

---

### Installation

```
flutter pub get

flutter run
```
<br>

### ScreenShot

<img src="/assets/Screenshots/1.jpg" width="400" height="600">

 ### License
 
 © Alik Kumar Ghosh, The Flutter torch project licensed under the GNU General Public License v3.0 [License](https://github.com/Alik-Kumar-Ghosh/Flutter_Torch/blob/master/LICENSE)
