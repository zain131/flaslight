//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <lamp/LampPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [LampPlugin registerWithRegistrar:[registry registrarForPlugin:@"LampPlugin"]];
}

@end
